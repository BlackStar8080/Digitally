<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Tally Sheets'); ?></title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        :root {
            --primary-blue: #2563eb;
            --secondary-blue: #3b82f6;
            --accent-blue: #1d4ed8;
            --text-light: rgba(255, 255, 255, 0.9);
            --text-white: #ffffff;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8fafc;
            min-height: 100vh;
            padding-top: 80px;
            line-height: 1.6;
        }

        /* 🔹 Enhanced Navbar */
        .navbar {
            background: #9d4edd;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: var(--shadow-lg);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            padding: 0;
            transition: all 0.3s ease;
        }

        .navbar-content {
            display: flex;
            align-items: center;
            padding: 16px 32px;
            max-width: 1400px;
            margin: 0 auto;
            justify-content: space-between;
            gap: 32px;
        }

        /* Brand/Logo area (optional - can add later) */
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-white);
            text-decoration: none;
            letter-spacing: -0.025em;
        }

        /* Navigation Links */
        .nav-links {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 8px;
            align-items: center;
            flex: 1;
            justify-content: center;
        }

        .nav-links li {
            position: relative;
        }

        /* Dropdown Navigation Styles */
        .dropdown-nav {
            position: relative;
        }

        .dropdown-nav > a {
            position: relative;
        }

        .dropdown-icon {
            font-size: 12px;
            transition: transform 0.3s ease;
        }

        .dropdown-nav:hover .dropdown-icon {
            transform: rotate(180deg);
        }

        .dropdown-menu-custom {
            position: absolute;
            top: 100%;
            left: 0;
            background: #ffffff;
            backdrop-filter: blur(10px);
            min-width: 200px;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            list-style: none;
            padding: 8px;
            margin: 8px 0 0 0;
            z-index: 1000;
            border: 1px solid #e2e8f0;
        }

        .dropdown-nav:hover .dropdown-menu-custom {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-menu-custom li {
            margin: 0;
        }

        .dropdown-menu-custom li a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #9d4edd !important;    /* ✅ PURPLE TEXT */
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s ease;
            font-size: 14px;
            font-weight: 600;
            white-space: nowrap;
            width: 100%;
        }

        .dropdown-menu-custom li a:hover {
            background: #f3e8ff !important;    /* ✅ LIGHT PURPLE HOVER */
            color: #7c3aed !important;    /* ✅ DARKER PURPLE ON HOVER */
            transform: translateX(4px);
        }

        .dropdown-menu-custom li a i {
            font-size: 16px;
            width: 20px;
        }

        /* Active dropdown state for mobile */
        .dropdown-nav.active-dropdown .dropdown-menu-custom {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        @media (max-width: 768px) {
            .dropdown-nav.active-dropdown .dropdown-menu-custom {
                transform: translateX(-50%) translateY(0);
            }
        }

        .nav-links li a {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-light);
            font-weight: 500;
            font-size: 15px;
            padding: 12px 20px;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            letter-spacing: 0.025em;
            white-space: nowrap;
        }

        .nav-links li a::before {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: 12px;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05));
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .nav-links li a:hover::before {
            opacity: 1;
        }

        .nav-links li a:hover {
            color: var(--text-white);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .nav-links li a.active {
            background: rgba(255, 255, 255, 0.15);
            color: var(--text-white);
            font-weight: 600;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2);
        }

        .nav-links li a.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 50%;
            transform: translateX(-50%);
            width: 24px;
            height: 2px;
            background: var(--text-white);
            border-radius: 1px;
        }

        /* Actions area - FIXED: removed absolute positioning */
        .nav-actions {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        /* Enhanced Logout button */
        .logout-btn {
            background: rgba(255, 255, 255, 0.15);
            color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 12px 20px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            letter-spacing: 0.025em;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 24px rgba(157, 78, 221, 0.15);
            backdrop-filter: blur(8px) saturate(180%);
            -webkit-backdrop-filter: blur(8px) saturate(180%);
        }

        .logout-btn::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.25), rgba(239,68,68,0.15));
            opacity: 0.7;
            pointer-events: none;
            transition: opacity 0.3s ease;
            border-radius: 12px;
        }

        .logout-btn:hover::before {
            opacity: 1;
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 32px rgba(157, 78, 221, 0.25);
            color: #ffffff;
        }

        .logout-btn:active {
            transform: translateY(0);
        }

        .logout-btn i,
        .logout-btn span {
            position: relative;
            z-index: 1;
        }

        /* Modal Enhancements */
        .modal-header.logout-modal {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
            border-bottom: none;
            padding: 24px;
        }

        .modal-content {
            border: none;
            border-radius: 16px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
        }

        .modal-body {
            padding: 24px;
            background: #ffffff;
        }

        .modal-footer {
            padding: 20px 24px;
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
        }

        .btn-close {
            filter: brightness(0) invert(1);
            opacity: 0.8;
        }

        .btn-close:hover {
            opacity: 1;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .navbar-content {
                padding: 14px 24px;
            }
            
            .nav-links {
                gap: 4px;
            }
            
            .nav-links li a {
                padding: 10px 16px;
                font-size: 14px;
            }
        }

        @media (max-width: 992px) {
            .nav-links li a {
                padding: 10px 12px;
            }
        }

        @media (max-width: 768px) {
            body {
                padding-top: 140px;
            }

            .navbar-content {
                flex-direction: column;
                padding: 16px 20px;
                gap: 16px;
            }

            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
                gap: 8px;
                width: 100%;
            }

            .nav-links li {
                flex: 1;
                min-width: calc(50% - 4px);
            }

            .nav-links li a {
                justify-content: center;
                padding: 10px 8px;
                font-size: 13px;
                border-radius: 8px;
            }

            .nav-actions {
                width: 100%;
                justify-content: center;
            }

            .logout-btn {
                padding: 10px 24px;
                font-size: 13px;
            }

            /* Mobile dropdown adjustments */
            .dropdown-menu-custom {
                position: fixed;
                left: 50%;
                transform: translateX(-50%) translateY(-10px);
                min-width: 240px;
            }

            .dropdown-nav:hover .dropdown-menu-custom {
                transform: translateX(-50%) translateY(0);
            }
        }

        @media (max-width: 480px) {
            .navbar-content {
                padding: 12px 16px;
            }

            .nav-links li {
                min-width: calc(33.333% - 6px);
            }

            .nav-links li a {
                padding: 8px 4px;
                font-size: 12px;
            }
        }

        /* Scrolled state - slight transparency */
        .navbar.scrolled {
            background: rgba(157, 78, 221, 0.95);
            backdrop-filter: blur(20px);
        }

        /* Add some demo content to test scrolling */
        .demo-content {
            padding: 40px 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .demo-card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: var(--shadow-sm);
            border: 1px solid #e2e8f0;
        }

        /* 🎉 NEW: Centered Modal-Style Toast Notifications */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes scaleIn {
            from { 
                transform: scale(0.7);
                opacity: 0;
            }
            to { 
                transform: scale(1);
                opacity: 1;
            }
        }

        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }

        .global-toast-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            z-index: 9998;
            display: none;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }

        .global-toast-overlay.show {
            display: flex;
        }

        .global-toast-modal {
            background: linear-gradient(135deg, #e8f5e9, #f1f8f4);
            border-radius: 24px;
            padding: 40px 32px 32px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            min-width: 340px;
            max-width: 400px;
            text-align: center;
            transform: scale(0.9);
            animation: scaleIn 0.3s ease forwards;
            border: 3px solid #e0e0e0;
        }

        .toast-icon-circle {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            box-shadow: 0 8px 24px rgba(76, 175, 80, 0.2);
        }

        .toast-icon-circle i {
            font-size: 48px;
            color: #4caf50;
        }

        .toast-title {
            font-weight: 700;
            color: #2e7d32;
            font-size: 24px;
            margin-bottom: 12px;
        }

        .toast-message {
            color: #5a5a5a;
            font-size: 15px;
            margin-bottom: 28px;
            line-height: 1.5;
        }

        .toast-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
        }

        .toast-btn-primary {
            background: #4caf50;
            color: white;
            border: none;
            padding: 12px 28px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
        }

        .toast-btn-primary:hover {
            background: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(76, 175, 80, 0.4);
        }

        .toast-btn-primary:active {
            transform: translateY(0);
        }

        .toast-btn-secondary {
            background: white;
            color: #5a5a5a;
            border: 2px solid #e0e0e0;
            padding: 12px 28px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .toast-btn-secondary:hover {
            background: #f5f5f5;
            border-color: #bdbdbd;
            transform: translateY(-2px);
        }

        .toast-btn-secondary:active {
            transform: translateY(0);
        }

        /* Responsive adjustments for toast */
        @media (max-width: 480px) {
            .global-toast-modal {
                min-width: 300px !important;
                padding: 32px 24px 24px !important;
                margin: 0 16px;
            }

            .toast-title {
                font-size: 20px;
            }

            .toast-message {
                font-size: 14px;
            }

            .toast-actions {
                flex-direction: column;
            }

            .toast-btn-primary,
            .toast-btn-secondary {
                width: 100%;
            }
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    
    <nav class="navbar" id="mainNavbar">
        <div class="navbar-content">
             <div class="nav-links">
                <a href="<?php echo e(route('dashboard')); ?>" class="navbar-brand">DigiTally</a> 
            <ul class="nav-links">
                <li><a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                    <i class="bi bi-speedometer2 me-1"></i>
                    <span>Dashboard</span>
                </a></li>
                <li><a href="<?php echo e(route('games.index')); ?>" class="<?php echo e(request()->routeIs('games.*') ? 'active' : ''); ?>">
                    <i class="bi bi-controller me-1"></i>
                    <span>Games</span>
                </a></li>
                <li><a href="<?php echo e(route('teams.index')); ?>" class="<?php echo e(request()->routeIs('teams.*') ? 'active' : ''); ?>">
                    <i class="bi bi-people-fill me-1"></i>
                    <span>Teams</span>
                </a></li>
                <li class="dropdown-nav">
                    <a href="<?php echo e(route('players.index')); ?>" class="<?php echo e(request()->routeIs('players.*') ? 'active' : ''); ?>">
                        <i class="bi bi-person-badge me-1"></i>
                        <span>Players</span>
                       
                    </a>
                    <ul class="dropdown-menu-custom">
                        <li><a href="<?php echo e(route('players.index')); ?>">
                            <i class="bi bi-list-ul me-2"></i>
                            Player List
                        </a></li>
                        <li><a href="<?php echo e(route('players.stats')); ?>">
                            <i class="bi bi-graph-up me-2"></i>
                            Player Stats
                        </a></li>
                    </ul>
                </li>
                <li><a href="<?php echo e(route('tournaments.index')); ?>" class="<?php echo e(request()->routeIs('tournaments.*') ? 'active' : ''); ?>">
                    <i class="bi bi-trophy me-1"></i>
                    <span>Tournaments</span>
                </a></li>
                <?php if(!session('is_guest')): ?>
    <li><a href="<?php echo e(route('scorekeepers.index')); ?>" class="<?php echo e(request()->routeIs('scorekeepers.*') ? 'active' : ''); ?>">
        <i class="bi bi-person-badge me-1"></i>
        <span>Scorekeeper Panel</span>
    </a></li>
    <li><a href="<?php echo e(route('reports.index')); ?>" class="<?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>">
        <i class="bi bi-bar-chart me-1"></i>
        <span>Reports</span>
    </a></li>
<?php endif; ?>
            </ul>
            
            <div class="nav-actions">
                <button class="logout-btn" data-bs-toggle="modal" data-bs-target="#logoutModal" type="button">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </button>
            </div>
        </div>
    </nav>

    
    <div class="main-container">
        
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    
    <div class="global-toast-overlay" id="globalToastOverlay">
        <div class="global-toast-modal" id="globalToastModal">
            <div class="toast-icon-circle">
                <i class="bi bi-check-circle-fill" id="globalToastIcon"></i>
            </div>
            <h3 class="toast-title" id="globalToastTitle">Success!</h3>
            <p class="toast-message" id="globalToastMessage">Your scoresheet has been created successfully</p>
            <div class="toast-actions">
                <button class="toast-btn-primary" id="globalToastViewDetails" style="display: none;">
                    View Details
                </button>
                <button class="toast-btn-secondary" id="globalToastClose">
                    Close
                </button>
            </div>
        </div>
    </div>

    
    <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"><?php echo csrf_field(); ?></form>

    <div class="modal fade" id="logoutModal" data-bs-backdrop="static" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header logout-modal">
                    <h5 class="modal-title d-flex align-items-center">
                        <i class="bi bi-exclamation-triangle me-2"></i> 
                        Confirm Logout
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-0">Are you sure you want to logout? You will be redirected to the login page.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i>
                        Cancel
                    </button>
                    <button type="button" class="btn btn-danger" id="confirmLogout">
                        <i class="bi bi-box-arrow-right me-1"></i>
                        Yes, Logout
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    
    <script>
        // Handle logout confirmation
        document.getElementById('confirmLogout').addEventListener('click', function () {
            document.getElementById('logoutForm').submit();
        });

        // Add scroll effect to navbar (optional)
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNavbar');
            if (window.scrollY > 10) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Add keyboard navigation support
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const logoutModal = bootstrap.Modal.getInstance(document.getElementById('logoutModal'));
                if (logoutModal) {
                    logoutModal.hide();
                }
                
                // Also close toast on Escape
                hideGlobalToast();
            }
        });

        // Mobile dropdown toggle support
        document.addEventListener('DOMContentLoaded', function() {
            const dropdownNavs = document.querySelectorAll('.dropdown-nav > a');
            
            dropdownNavs.forEach(function(dropdownLink) {
                dropdownLink.addEventListener('click', function(e) {
                    // Only prevent default on mobile
                    if (window.innerWidth <= 768) {
                        e.preventDefault();
                        const parent = this.parentElement;
                        
                        // Close other dropdowns
                        document.querySelectorAll('.dropdown-nav').forEach(function(nav) {
                            if (nav !== parent) {
                                nav.classList.remove('active-dropdown');
                            }
                        });
                        
                        // Toggle current dropdown
                        parent.classList.toggle('active-dropdown');
                    }
                });
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.dropdown-nav')) {
                    document.querySelectorAll('.dropdown-nav').forEach(function(nav) {
                        nav.classList.remove('active-dropdown');
                    });
                }
            });
        });

        // 🎉 NEW: Global Toast Functions
        function showGlobalToast(message, title = 'Success!', options = {}) {
            try {
                const overlay = document.getElementById('globalToastOverlay');
                const titleEl = document.getElementById('globalToastTitle');
                const messageEl = document.getElementById('globalToastMessage');
                const closeBtn = document.getElementById('globalToastClose');
                const viewDetailsBtn = document.getElementById('globalToastViewDetails');
                const iconEl = document.getElementById('globalToastIcon');

                if (!overlay || !titleEl || !messageEl) return;

                // Set content
                titleEl.textContent = title;
                messageEl.textContent = message;

                // Handle icon (optional customization)
                if (options.icon) {
                    iconEl.className = `bi bi-${options.icon}`;
                }

                // Handle view details button
                if (options.onViewDetails) {
                    viewDetailsBtn.style.display = 'inline-block';
                    viewDetailsBtn.onclick = options.onViewDetails;
                } else {
                    viewDetailsBtn.style.display = 'none';
                }

                // Show overlay
                overlay.classList.add('show');

                // Close button handler
                closeBtn.onclick = hideGlobalToast;

                // Optional auto-hide
                if (options.autoHide !== false) {
                    const duration = options.duration || 4000;
                    setTimeout(hideGlobalToast, duration);
                }

                // Close on overlay click
                overlay.onclick = function(e) {
                    if (e.target === overlay) {
                        hideGlobalToast();
                    }
                };
            } catch (err) {
                console.error('Toast error', err);
            }
        }

        function hideGlobalToast() {
            const overlay = document.getElementById('globalToastOverlay');
            if (overlay) {
                overlay.classList.remove('show');
            }
        }

        // If there's a success message in session (e.g., after login), show it
        document.addEventListener('DOMContentLoaded', function() {
            <?php if(session('success')): ?>
                showGlobalToast(<?php echo json_encode(session('success')); ?>);
            <?php endif; ?>
        });
    </script>

    
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\dell\Documents\Gitss\Digitally\resources\views/layouts/app.blade.php ENDPATH**/ ?>