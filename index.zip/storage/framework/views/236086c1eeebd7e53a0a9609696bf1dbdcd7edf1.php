

<?php $__env->startSection('title', 'Tournaments'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* Toast Notification Styles */
.toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
}

.toast-notification {
    background: white;
    border-radius: 12px;
    padding: 1rem 1.5rem;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
    display: flex;
    align-items: center;
    gap: 1rem;
    min-width: 320px;
    max-width: 400px;
    opacity: 0;
    transform: translateX(400px);
    transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    border-left: 4px solid #28a745;
}

.toast-notification.show {
    opacity: 1;
    transform: translateX(0);
}

.toast-notification.hide {
    opacity: 0;
    transform: translateX(400px);
}

.toast-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #28a745, #20c997);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    flex-shrink: 0;
}

.toast-content {
    flex: 1;
}

.toast-title {
    font-weight: 700;
    color: #212529;
    margin-bottom: 0.25rem;
    font-size: 14px;
}

.toast-message {
    color: #6c757d;
    font-size: 13px;
    margin: 0;
}

.toast-close {
    background: none;
    border: none;
    color: #6c757d;
    font-size: 20px;
    cursor: pointer;
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.2s ease;
    flex-shrink: 0;
}

.toast-close:hover {
    background: #f0f0f0;
    color: #212529;
}

/* Fade in animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.fade-in-card {
    animation: fadeIn 0.4s ease-in;
}

/* Root Variables */
:root {
    --primary-purple: #9d4edd;
    --secondary-purple: #7c3aed;
    --accent-purple: #5f2da8;
    --light-purple: #ffffff;
    --border-color: #e5e7eb;
    --text-dark: #212529;
    --text-muted: #6c757d;
    --background-light: #f8faff;
    --hover-purple: #ede9fe;
}

.tournaments-page {
    min-height: 100vh;
    background-color: var(--light-purple);
    padding: 2rem 0;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
}

.page-card {
    background: white;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.page-header {
    background: linear-gradient(135deg, var(--primary-purple), var(--secondary-purple), var(--accent-purple));
    color: white;
    padding: 2rem;
}

.page-title {
    font-size: 28px;
    font-weight: 700;
    margin: 0;
    text-transform: uppercase;
    letter-spacing: 0.02em;
}

.page-content {
    padding: 2rem;
}

.controls-section {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1.5rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
}

.actions-group {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-left: auto;
}

.search-container {
    position: relative;
    width: 280px;
}

.search-input {
    width: 100%;
    height: 44px;
    padding: 0 50px 0 16px;
    border: 2px solid var(--border-color);
    border-radius: 22px;
    font-size: 14px;
    background: white;
    transition: all 0.3s ease;
}

.search-input:focus {
    outline: none;
    border-color: var(--secondary-purple);
    box-shadow: 0 0 0 3px rgba(157, 78, 221, 0.1);
}

.search-btn {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    background: var(--primary-purple);
    color: white;
    border: none;
    border-radius: 50%;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.search-btn:hover {
    background: var(--secondary-purple);
    transform: translateY(-50%) scale(1.05);
}

.add-btn {
    background: var(--primary-purple);
    color: white;
    padding: 0 24px;
    height: 44px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    white-space: nowrap;
}

.add-btn:hover {
    background: var(--secondary-purple);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(157, 78, 221, 0.3);
}

/* Tournaments Grid */
.tournaments-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 2rem;
}

.tournament-card {
    background: white;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    padding: 1.5rem;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    text-decoration: none;
    color: inherit;
    display: block;
    min-height: 180px;
}

.tournament-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--primary-purple), var(--secondary-purple));
    opacity: 0;
    transition: opacity 0.3s ease;
}

.tournament-card:hover::before {
    opacity: 1;
}

.tournament-card:hover {
    border-color: var(--primary-purple);
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(157, 78, 221, 0.13);
}

.tournament-card:hover .tournament-actions {
    opacity: 1;
}

.tournament-actions {
    position: absolute;
    top: 12px;
    left: 12px;
    display: flex;
    gap: 6px;
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 10;
}

.btn-card-action {
    width: 32px;
    height: 32px;
    border-radius: 6px;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 14px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.btn-card-edit {
    background: var(--primary-purple);
    color: white;
}

.btn-card-edit:hover {
    background: var(--secondary-purple);
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(157, 78, 221, 0.3);
}

.btn-card-delete {
    background: #dc3545;
    color: white;
}

.btn-card-delete:hover {
    background: #c82333;
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(220, 53, 69, 0.3);
}

.tournament-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
    padding-top: 2.5rem;
}

.tournament-info {
    flex: 1;
    padding-right: 1rem;
}

.tournament-name {
    font-size: 18px;
    font-weight: 700;
    color: var(--text-dark);
    margin: 0 0 0.5rem 0;
    line-height: 1.3;
}

.tournament-date {
    font-size: 13px;
    color: var(--text-muted);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.tournament-date::before {
    content: '📅';
    font-size: 12px;
}

.sport-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    flex-shrink: 0;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.sport-icon.basketball {
    background: linear-gradient(135deg, #ff6b35, #ff8e53);
}

.sport-icon.volleyball {
    background: linear-gradient(135deg, #4ecdc4, #44a08d);
}

.tournament-type {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(157, 78, 221, 0.08);
    color: var(--primary-purple);
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-top: 1.5rem;
}

.tournament-type::before {
    content: '🏆';
    font-size: 14px;
}

/* Modal Styling */
.modal-content {
    border: none;
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
}

.modal-header {
    background: linear-gradient(135deg, var(--primary-purple), var(--secondary-purple));
    color: white;
    border: none;
    padding: 1.5rem 2rem;
}

.modal-title {
    font-weight: 700;
    font-size: 20px;
}

.btn-close {
    filter: brightness(0) invert(1);
    opacity: 0.8;
}

.btn-close:hover {
    opacity: 1;
}

.modal-footer .btn-primary {
    background: var(--primary-purple);
    border: none;
    color: #fff;
    transition: 0.3s ease;
}

.modal-footer .btn-primary:hover {
    background: var(--secondary-purple);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(157, 78, 221, 0.3);
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 4rem 2rem;
    color: var(--text-muted);
}

.empty-state i {
    font-size: 4rem;
    margin-bottom: 1rem;
    opacity: 0.3;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        padding: 0 0.5rem;
    }
    
    .page-header {
        padding: 1.5rem;
    }
    
    .page-title {
        font-size: 24px;
    }
    
    .page-content {
        padding: 1.5rem;
    }
    
    .controls-section {
        flex-direction: column;
        align-items: stretch;
        gap: 1rem;
    }
    
    .actions-group {
        justify-content: center;
        margin-left: 0;
    }
    
    .search-container {
        width: 100%;
        max-width: 300px;
    }
    
    .tournaments-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }

    .tournament-actions {
        opacity: 1;
        background: rgba(255, 255, 255, 0.95);
        padding: 4px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    }

    .toast-container {
        left: 10px;
        right: 10px;
    }

    .toast-notification {
        min-width: auto;
        max-width: 100%;
    }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Toast Notification -->
<div class="toast-container">
    <div class="toast-notification" id="successToast">
        <div class="toast-icon">
            <i class="bi bi-check-circle-fill"></i>
        </div>
        <div class="toast-content">
            <div class="toast-title">Success!</div>
            <p class="toast-message" id="toastMessage">Tournament has been successfully added.</p>
        </div>
        <button class="toast-close" onclick="hideToast()">
            <i class="bi bi-x"></i>
        </button>
    </div>
</div>

<div class="tournaments-page">
    <div class="container">
        <div class="page-card">
            <!-- Page Header -->
            <div class="page-header">
                <h1 class="page-title">Tournaments Management</h1>
            </div>
            
            <!-- Page Content -->
            <div class="page-content">
                <!-- Controls Section -->
                <div class="controls-section">
                    <div style="flex: 1;"></div>
                    <div class="actions-group">
                        <div class="search-container">
                            <input type="text" class="search-input" id="searchInput" placeholder="Search tournaments...">
                            <button class="search-btn" type="button">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                        <?php if(!session('is_guest')): ?>
                            <button class="add-btn" type="button" data-bs-toggle="modal" data-bs-target="#addTournamentModal">
                                <i class="bi bi-plus-circle"></i>
                                Add Tournament
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Tournaments Grid -->
                <div class="tournaments-grid" id="tournamentsGrid">
                    <?php $__empty_1 = true; $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="tournament-card fade-in-card" style="animation-delay: <?php echo e($index * 0.05); ?>s"
                            data-name="<?php echo e(strtolower($tournament->name)); ?>"
                            data-sport="<?php echo e(strtolower($tournament->sport->sports_name ?? '')); ?>"
                            data-id="<?php echo e($tournament->id); ?>">
                            <?php if(!session('is_guest')): ?>
                                <div class="tournament-actions">
                                    <button class="btn-card-action btn-card-edit" onclick="openEditModal(<?php echo e($tournament->id); ?>, event)" title="Edit Tournament">
                                        <i class="bi bi-pencil-fill"></i>
                                    </button>
                                    <button class="btn-card-action btn-card-delete" onclick="deleteTournament(<?php echo e($tournament->id); ?>, '<?php echo e(addslashes($tournament->name)); ?>', event)" title="Delete Tournament">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <a href="<?php echo e(route('tournaments.show', $tournament->id)); ?>" style="text-decoration: none; color: inherit; display: block;">
                                <div class="tournament-header">
                                    <div class="tournament-info">
                                        <h3 class="tournament-name"><?php echo e($tournament->name); ?></h3>
                                        <p class="tournament-date">
                                            <?php echo e(\Carbon\Carbon::parse($tournament->start_date ?? $tournament->date ?? now())->format('F d, Y')); ?>

                                        </p>
                                    </div>
                                    <div class="sport-icon <?php echo e(strtolower($tournament->sport->sports_name ?? '')); ?>">
                                        <?php $sportName = strtolower($tournament->sport->sports_name ?? ''); ?>
                                        <?php if($sportName === 'basketball'): ?> 🏀
                                        <?php elseif($sportName === 'volleyball'): ?> 🏐
                                        <?php else: ?> 🏆
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty-state">
                            <i class="bi bi-trophy"></i>
                            <h3>No tournaments found</h3>
                            <p>Create your first tournament to get started!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Tournament Modal -->
<div class="modal fade" id="addTournamentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" action="<?php echo e(route('tournaments.store')); ?>" class="modal-content">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="modal_type" value="add">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-trophy me-2"></i> Add New Tournament
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="name" class="form-label">Tournament Name</label>
                    <input type="text" class="form-control" id="name" name="name"
                           value="<?php echo e(old('name')); ?>"
                           required pattern="^[a-zA-Z0-9\s]+$"
                           title="Only letters, numbers, and spaces are allowed.">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="division" class="form-label">Division</label>
                    <input type="text" class="form-control" id="division" name="division"
                           value="<?php echo e(old('division')); ?>"
                           required pattern="^[a-zA-Z0-9\s]+$"
                           title="Only letters, numbers, and spaces are allowed.">
                    <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="tournamentDate" class="form-label">Tournament Date</label>
                    <input type="date" id="tournamentDate" name="start_date" class="form-control"
                           value="<?php echo e(old('start_date')); ?>">
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="teamSport" class="form-label">Sport</label>
                    <select name="sport_id" id="teamSport" class="form-select" required>
                        <option value="">Select sport</option>
                        <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sport->sports_id); ?>" <?php echo e(old('sport_id') == $sport->sports_id ? 'selected' : ''); ?>>
                                <?php echo e($sport->sports_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['sport_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg me-2"></i> Create Tournament
                </button>
            </div>
        </form>
    </div>
</div>



<!-- Edit Tournament Modal -->
<div class="modal fade" id="editTournamentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" id="editTournamentForm" class="modal-content">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="modal_type" value="edit">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-pencil-square me-2"></i> Edit Tournament
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="edit_name" class="form-label">Tournament Name</label>
                    <input type="text" class="form-control" id="edit_name" name="name"
                           value="<?php echo e(old('name')); ?>" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="edit_division" class="form-label">Division</label>
                    <input type="text" class="form-control" id="edit_division" name="division"
                           value="<?php echo e(old('division')); ?>" required>
                    <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="edit_date" class="form-label">Tournament Date</label>
                    <input type="date" id="edit_date" name="start_date" class="form-control"
                           value="<?php echo e(old('start_date')); ?>">
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="edit_sport" class="form-label">Sports Type</label>
                    <select id="edit_sport" name="sport_id" class="form-select" required>
                        <option value="">Select a sport</option>
                        <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sport->sports_id); ?>" <?php echo e(old('sport_id') == $sport->sports_id ? 'selected' : ''); ?>>
                                <?php echo e($sport->sports_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['sport_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg me-2"></i> Update Tournament
                </button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
    // Check for validation errors for add modal
    <?php if($errors->any() && old('modal_type') === 'add'): ?>
        var addModal = new bootstrap.Modal(document.getElementById('addTournamentModal'));
        addModal.show();
    <?php endif; ?>

    // Check for validation errors for edit modal
    <?php if($errors->any() && old('modal_type') === 'edit'): ?>
        var editModal = new bootstrap.Modal(document.getElementById('editTournamentModal'));
        editModal.show();
    <?php endif; ?>
});
// Toast Notification Functions
function showToast(message) {
    const toast = document.getElementById('successToast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastMessage.textContent = message;
    toast.classList.add('show');
    
    setTimeout(() => {
        hideToast();
    }, 4000);
}

function hideToast() {
    const toast = document.getElementById('successToast');
    toast.classList.remove('show');
    toast.classList.add('hide');
    
    setTimeout(() => {
        toast.classList.remove('hide');
    }, 400);
}

document.addEventListener('DOMContentLoaded', function () {
    // Check for Laravel success message
   

    // Store tournaments data
    const tournaments = <?php echo json_encode($tournaments, 15, 512) ?>;

    // Client-side search
    const searchInput = document.getElementById('searchInput');
    
    function filterCards() {
        const q = (searchInput.value || '').trim().toLowerCase();
        const cards = document.querySelectorAll('.tournament-card');
        
        cards.forEach(card => {
            const name = (card.dataset.name || '').toLowerCase();
            const sport = (card.dataset.sport || '').toLowerCase();
            const bracket = (card.dataset.bracket || '').toLowerCase();
            const match = !q || name.includes(q) || sport.includes(q) || bracket.includes(q);
            card.style.display = match ? '' : 'none';
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('input', filterCards);
    }
    
    // Set min date for date inputs
    const dateInput = document.getElementById('tournamentDate');
    if (dateInput) {
        dateInput.min = new Date().toISOString().split('T')[0];
    }

    // Edit Tournament Function
            window.openEditModal = function(tournamentId, event) {
            event.preventDefault();
            event.stopPropagation();
            
            const tournament = tournaments.find(t => t.id === tournamentId);
            if (!tournament) return;

            const form = document.getElementById('editTournamentForm');
            form.action = `/tournaments/${tournamentId}`;
            
            document.getElementById('edit_name').value = tournament.name || '';
            document.getElementById('edit_division').value = tournament.division || '';
            document.getElementById('edit_date').value = tournament.start_date || '';
            document.getElementById('edit_sport').value = tournament.sport_id || '';

            const modal = new bootstrap.Modal(document.getElementById('editTournamentModal'));
            modal.show();
        };

    // Delete Tournament Function
    window.deleteTournament = function(tournamentId, tournamentName, event) {
        event.preventDefault();
        event.stopPropagation();
        
        if (confirm(`Are you sure you want to delete "${tournamentName}"? This action cannot be undone.`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `/tournaments/${tournamentId}`;
            
            // Get CSRF token
            let csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
            if (!csrfToken) {
                csrfToken = '<?php echo e(csrf_token()); ?>';
            }
            
            form.innerHTML = `
                <input type="hidden" name="_token" value="${csrfToken}">
                <input type="hidden" name="_method" value="DELETE">
            `;
            
            document.body.appendChild(form);
            form.submit();
        }
    };
});

// Numbers-only input helper
// Usage: add class="numbers-only" to any <input> you want to restrict to digits only
(function() {
    function enableNumbersOnly(selector) {
        selector = selector || '.numbers-only';
        document.querySelectorAll(selector).forEach(function(input) {
            // Clean non-digits on input (handles mobile keyboards and IME)
            input.addEventListener('input', function(e) {
                var caret = this.selectionStart;
                var cleaned = this.value.replace(/\D+/g, '');
                if (this.value !== cleaned) {
                    this.value = cleaned;
                    try {
                        this.setSelectionRange(caret - 1, caret - 1);
                    } catch (err) {
                        // ignore if not supported
                    }
                }
            });

            // Prevent non-digit keypresses
            input.addEventListener('keypress', function(e) {
                var char = String.fromCharCode(e.which || e.keyCode);
                // allow control keys (backspace handled separately by browsers)
                if (!/\d/.test(char) && !e.ctrlKey && !e.metaKey) {
                    e.preventDefault();
                }
            });

            // Handle paste events: strip non-digits from pasted content
            input.addEventListener('paste', function(e) {
                var paste = (e.clipboardData || window.clipboardData).getData('text');
                if (/\D/.test(paste)) {
                    e.preventDefault();
                    var digits = paste.replace(/\D+/g, '');
                    // insert cleaned digits at caret position
                    var start = this.selectionStart || 0;
                    var end = this.selectionEnd || 0;
                    var val = this.value;
                    this.value = val.slice(0, start) + digits + val.slice(end);
                    try { this.setSelectionRange(start + digits.length, start + digits.length); } catch (err) {}
                }
            });
        });
    }

    // enable on DOM ready
    document.addEventListener('DOMContentLoaded', function() {
        enableNumbersOnly();
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Documents\Gitss\Digitally\resources\views/tournaments.blade.php ENDPATH**/ ?>